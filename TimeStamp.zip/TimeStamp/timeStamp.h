#ifndef TIMESTAMP_H_INCLUDED
#define TIMESTAMP_H_INCLUDED
# include <iostream>

class timeStamp{
    private:
        int s;
        int m;
        int h;
    public:
        timeStamp();
        timeStamp(int,int,int);
        bool operator ==(timeStamp);
        bool operator !=(timeStamp);
        bool operator > (timeStamp);
        bool operator < (timeStamp);
        friend std::ostream& operator << (std::ostream&, timeStamp&); // Just like toString method in Java

};
#endif // TIMESTAMP_H_INCLUDED
